package edu.upenn.cis350.hwk4.logging;

/**
 * Created by RajatBhageria on 3/29/16.
 */
public abstract class Logger {
    protected Subject subject;
    public abstract void info(String e);
}
