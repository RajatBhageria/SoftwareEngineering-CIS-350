package edu.upenn.cis350.hwk4.controller;

import java.util.ArrayList;

/**
 * Created by RajatBhageria on 3/30/16.
 * This is the interface for the strategy design pattern
 */
public interface Strategy {
    ArrayList<String> getAnswer();
}
